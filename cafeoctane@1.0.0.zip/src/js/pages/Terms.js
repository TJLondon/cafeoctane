import Layout from '../common/layout/Layout';
import React from 'react';

export default class Terms extends React.Component {
    render() {
        return (
            <Layout>
                <div className="content">
                    <h1>Terms of use</h1>
                </div>
            </Layout>
        )
    }
}