import Layout from '../common/layout/Layout';
import React from 'react';

export default class About extends React.Component {
    render() {
        return (
            <Layout>
                <div className="content">
                    <h1>hello</h1>
                </div>
            </Layout>
        )
    }
}