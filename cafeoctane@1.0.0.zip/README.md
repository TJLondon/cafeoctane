   _____          ______ ______ ____   _____ _______       _   _ ______
  / ____|   /\   |  ____|  ____/ __ \ / ____|__   __|/\   | \ | |  ____|
 | |       /  \  | |__  | |__ | |  | | |       | |  /  \  |  \| | |__
 | |      / /\ \ |  __| |  __|| |  | | |       | | / /\ \ | . ` |  __|
 | |____ / ____ \| |    | |___| |__| | |____   | |/ ____ \| |\  | |____
  \_____/_/    \_\_|    |______\____/ \_____|  |_/_/    \_\_| \_|______|



# cafeoctane

This is a personal work-in-progress project. It's an events web application for cars and coffee and motor shows in Europe.

Built on React, Node, Express and MongoDB.